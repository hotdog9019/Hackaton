﻿                &НаСервереБезКонтекста
Функция ПолучитьДанныеВыручки()

	Запрос = Новый Запрос;
	Запрос.Текст =
	"ВЫБРАТЬ
	|	НАЧАЛОПЕРИОДА(ВыручкаКлуба.Период, МЕСЯЦ) КАК Месяц,
	|	СУММА(ВыручкаКлуба.Сумма) КАК Сумма
	|ИЗ
	|	РегистрНакопления.ВыручкаКлуба КАК ВыручкаКлуба
	|СГРУППИРОВАТЬ ПО
	|	НАЧАЛОПЕРИОДА(ВыручкаКлуба.Период, МЕСЯЦ)
	|УПОРЯДОЧИТЬ ПО
	|	Месяц";

	Выборка = Запрос.Выполнить().Выбрать();

	Массив = Новый Массив;

	Пока Выборка.Следующий() Цикл
		Стр = Новый Структура;
		Стр.Вставить("Месяц", Формат(Выборка.Месяц, "ДФ=ММ.yyyy"));
		Стр.Вставить("Сумма", Выборка.Сумма);
		Массив.Добавить(Стр);
	КонецЦикла;

	Возврат Массив;

КонецФункции


&НаКлиенте
Процедура ПриОткрытии(Отказ)

	Объект.HTMLДашборд = "
	|<html>
	|<body style='background:#f5f6f8;font-family:Arial;padding:30px;'>
	|<h1 style='color:#2563eb;'>HTML работает!</h1>
	|<p>Дашборд подключен правильно.</p>
	|</body>
	|</html>";

КонецПроцедуры

&НаКлиенте
Процедура ОбновитьДашборд()

	Данные = ПолучитьДанныеВыручки();

	Максимум = 1;
	Итого = 0;

	Для Каждого Стр Из Данные Цикл
		Если Стр.Сумма > Максимум Тогда
			Максимум = Стр.Сумма;
		КонецЕсли;
		Итого = Итого + Стр.Сумма;
	КонецЦикла;

	HTML = "
	|<html>
	|<head>
	|<style>
	|body { font-family: Segoe UI, Arial; background:#f5f6f8; padding:20px; color:#1e293b; }
	|.card { background:white; border-radius:16px; padding:20px; box-shadow:0 4px 14px rgba(0,0,0,.08); }
	|h1 { margin:0 0 10px 0; font-size:24px; }
	|.total { font-size:28px; font-weight:bold; margin:10px 0 25px 0; color:#2563eb; }
	|.chart { display:flex; align-items:flex-end; height:320px; gap:22px; border-left:2px solid #cbd5e1; border-bottom:2px solid #cbd5e1; padding:20px; }
	|.bar-wrap { width:70px; text-align:center; }
	|.bar { width:100%; background:#3b82f6; border-radius:8px 8px 0 0; min-height:4px; }
	|.value { font-size:12px; margin-bottom:6px; color:#334155; }
	|.label { font-size:12px; margin-top:8px; color:#64748b; }
	|.note { margin-top:18px; font-size:13px; color:#64748b; }
	|</style>
	|</head>
	|<body>
	|<div class='card'>
	|<h1>Дашборд выручки клуба</h1>
	|<div class='total'>Итого: " + Формат(Итого, "ЧДЦ=2") + " ₽</div>
	|<div class='chart'>";

	Для Каждого Стр Из Данные Цикл

		Высота = Окр((Стр.Сумма / Максимум) * 280, 0);

		HTML = HTML + "
		|<div class='bar-wrap'>
		|	<div class='value'>" + Формат(Стр.Сумма, "ЧДЦ=0") + "</div>
		|	<div class='bar' style='height:" + Формат(Высота, "ЧГ=0") + "px'></div>
		|	<div class='label'>" + Стр.Месяц + "</div>
		|</div>";

	КонецЦикла;

	HTML = HTML + "
	|</div>
	|<div class='note'>Источник данных: регистр накопления ВыручкаКлуба. График построен средствами HTML внутри 1С.</div>
	|</div>
	|</body>
	|</html>";

	ДокументHTML = Элементы.HTMLДашборд.Документ;

Если ДокументHTML <> Неопределено Тогда
	ДокументHTML.open();
	ДокументHTML.write(HTML);
	ДокументHTML.close();
	КонецЕсли;

КонецПроцедуры